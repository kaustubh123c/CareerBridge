module.exports = {
    php: "/usr/bin/php"              // macOS/Ubuntu
    php: "C:\\xampp\\php\\php.exe"   // Windows
  }